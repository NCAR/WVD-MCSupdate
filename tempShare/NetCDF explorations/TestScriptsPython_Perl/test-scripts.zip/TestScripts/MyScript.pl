
#This is just a dummy perl script that prints back to the shell
print "This is a test perl script\n";
print "This is the argument I passed in: $ARGV[0]\n";
